package me.finz0.osiris.module.modules.render;

import me.finz0.osiris.module.Module;

public class CapesModule extends Module {
    public CapesModule() {
        super("Capes", Category.RENDER);
        setEnabled(true);
        setDrawn(false);
    }
}
