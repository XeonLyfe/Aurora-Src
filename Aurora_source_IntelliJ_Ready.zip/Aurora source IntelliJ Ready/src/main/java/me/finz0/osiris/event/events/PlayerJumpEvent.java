package me.finz0.osiris.event.events;

import me.finz0.osiris.event.OsirisEvent;

public class PlayerJumpEvent extends OsirisEvent {
    public PlayerJumpEvent(){
        super();
    }
}
