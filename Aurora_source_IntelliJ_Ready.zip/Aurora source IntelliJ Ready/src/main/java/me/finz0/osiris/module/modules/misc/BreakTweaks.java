package me.finz0.osiris.module.modules.misc;

import me.finz0.osiris.module.Module;

public class BreakTweaks extends Module {
    public BreakTweaks() {
        super("BreakTweaks", Category.MISC, "Tweaks block breaking");
    }
}
