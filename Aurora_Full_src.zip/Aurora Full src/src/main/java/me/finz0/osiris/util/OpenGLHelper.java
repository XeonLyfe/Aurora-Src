package me.finz0.osiris.util;

public class OpenGLHelper {
}
