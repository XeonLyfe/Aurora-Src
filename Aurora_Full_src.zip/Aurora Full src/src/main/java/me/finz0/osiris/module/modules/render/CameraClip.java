package me.finz0.osiris.module.modules.render;

import me.finz0.osiris.module.Module;

public class CameraClip extends Module {
    public CameraClip() {
        super("CameraClip", Category.RENDER, "makes the third person camera clip through blocks");
    }
}
