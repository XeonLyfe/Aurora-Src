package me.finz0.osiris.gui.clickgui.listener;

import me.finz0.osiris.gui.clickgui.elements.CheckButton;

public interface CheckButtonClickListener {

    void onCheckButtonClick(CheckButton checkButton);
}
