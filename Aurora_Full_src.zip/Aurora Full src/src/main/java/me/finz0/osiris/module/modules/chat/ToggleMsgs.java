package me.finz0.osiris.module.modules.chat;

import me.finz0.osiris.module.Module;

public class ToggleMsgs extends Module {
    public ToggleMsgs() {
        super("ToggleMsgs", Category.CHAT, "Sends a client side message when you toggle any module");
    }
}
