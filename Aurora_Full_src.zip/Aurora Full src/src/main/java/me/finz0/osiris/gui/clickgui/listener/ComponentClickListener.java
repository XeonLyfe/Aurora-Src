package me.finz0.osiris.gui.clickgui.listener;

import me.finz0.osiris.gui.clickgui.base.Component;

public interface ComponentClickListener {

    void onComponenetClick(Component component, int button);

}
